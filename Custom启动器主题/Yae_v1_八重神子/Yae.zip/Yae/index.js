function play() {
    var audio = new Audio('https://alt3ri.com/other/music/yae.mp3');
    audio.play();
}
play();