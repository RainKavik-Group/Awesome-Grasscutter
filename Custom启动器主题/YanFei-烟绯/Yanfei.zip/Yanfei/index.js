document.getElementsByClassName('image')[0].innerHTML += '<div class="yanfei1"><img src="https://alt3ri.com/img/yanfei/yanfei1.png" width="115" height="100" style="vertical-align:middle"></div>'
document.getElementsByClassName('image')[0].innerHTML += '<div class="yanfei2"><img src="https://alt3ri.com/img/yanfei/yanfei2.png" width="115" height="100" style="vertical-align:middle"></div>'
    /*function play() {
        var audio = new Audio("https://alt3ri.com/other/music/yae.mp3");
        audio.play();
    }
    play();*/